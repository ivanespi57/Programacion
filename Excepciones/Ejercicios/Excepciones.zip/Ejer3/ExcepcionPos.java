public class ExcepcionPos extends Exception {
    
    public ExcepcionPos(String mensaje){
        super(mensaje);
    }
}
