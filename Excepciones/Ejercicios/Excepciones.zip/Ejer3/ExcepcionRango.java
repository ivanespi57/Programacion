public class ExcepcionRango extends Exception{
    public ExcepcionRango(String mensaje){
        super(mensaje);
    }
}
