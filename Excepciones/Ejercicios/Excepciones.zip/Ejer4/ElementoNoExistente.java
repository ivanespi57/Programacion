public class ElementoNoExistente extends Exception{
    public ElementoNoExistente(String mensaje){
        super(mensaje);
    }
}
