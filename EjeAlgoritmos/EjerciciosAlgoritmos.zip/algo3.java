public class algo3 {
    public static void main(String[] args) {
        
        int n = 0;
        int suma = 0;
        
        while (suma<=100){
            n++;
            suma = suma + n;
    }
    System.out.println(suma);
}

}    

