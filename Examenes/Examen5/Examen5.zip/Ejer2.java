
import java.util.Scanner;

public class Ejer2 {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);

        int prim = sc.nextInt();
        int seg = sc.nextInt();

        while (prim != 0 && seg != 0){

        }
    }
}
